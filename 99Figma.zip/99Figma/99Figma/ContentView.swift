//
//  ContentView.swift
//  99Figma
//
//  Created by prk on 03/11/24.
//

import SwiftUI

@main

struct figmaproject : App{
    
    var body: some Scene{
        WindowGroup{
            PropertyListView()
        }
    }
}

